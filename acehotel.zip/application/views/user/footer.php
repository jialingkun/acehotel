<footer>
<nav class="navbar fixed-bottom navbar-expand navbar-light bg-light text-center no-padding" >
    <ul class="navbar-nav" style="margin:auto; width:100%;">
      <!-- <li class="nav-item " style="margin:auto; width:100%;">
        <a class="nav-link" id="dashboard_footer" href="<?=base_url("/index.php/dashboarduser");?>" style="padding:10px">Dashboard</a>
      </li> -->
      <li class="nav-item" style="margin:auto; width:100%;">
        <a class="nav-link" id="explore_footer" href="<?=base_url("/index.php/dashboarduser");?>" style="padding:10px">Explore</a>
      </li>
      <li class="nav-item" style="margin:auto; width:100%;">
        <a class="nav-link" id="order_footer" href="<?=base_url("/index.php/orderuser");?>" style="padding:10px">Order</a>
      </li>
      <li class="nav-item" style="margin:auto; width:100%;">
        <a class="nav-link" id="account_footer" href="<?=base_url("/index.php/profileuser");?>" style="padding:10px">Account</a>
      </li>
    </ul>
</nav>
</footer>