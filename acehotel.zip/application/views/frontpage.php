<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>FRONT PAGE</title>
</head>
<body>
	<a href="<?php echo base_url() ?>index.php/loginadmin">LOGIN ADMIN</a>
	<br>
	<a href="<?php echo base_url() ?>index.php/loginowner">LOGIN OWNER</a>
	<br>
	<a href="<?php echo base_url() ?>index.php/loginreceptionist">LOGIN RECEPTIONIST</a>
	<br>
	<a href="<?php echo base_url() ?>index.php/loginuser">LOGIN User</a>
</body>
</html>