<footer>
<nav class="navbar fixed-bottom navbar-expand navbar-light bg-light text-center no-padding" >
    <ul class="navbar-nav" style="margin:auto; width:100%;">
      <li class="nav-item " style="margin:auto; width:100%;">
        <a class="nav-link" id="dashboard_footer" href="<?=base_url("/index.php/dashboardadmin");?>" style="padding:10px">Dashboard</a>
      </li>
      <li class="nav-item" style="margin:auto; width:100%;">
        <a class="nav-link" id="booking_footer" href="<?=base_url("/index.php/bookingadmin");?>" style="padding:10px">Bookings</a>
      </li>
      <li class="nav-item" style="margin:auto; width:100%;">
        <a class="nav-link" id="report_footer" href="<?=base_url("/index.php/reportadmin");?>" style="padding:10px">Report</a>
      </li>
      <li class="nav-item" style="margin:auto; width:100%;">
        <a class="nav-link" id="management_footer" href="<?=base_url("/index.php/managementadmin");?>" style="padding:10px">Manage</a>
      </li>
    </ul>
</nav>
</footer>