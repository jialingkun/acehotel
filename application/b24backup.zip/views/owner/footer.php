<footer>
<nav class="navbar fixed-bottom navbar-expand navbar-light bg-light text-center no-padding" >
    <ul class="navbar-nav" style="margin:auto; width:100%;">
      <li class="nav-item " style="margin:auto; width:100%;">
        <a class="nav-link" id="dashboard_footer" href="<?=base_url("/index.php/dashboardowner");?>" style="padding:10px">Dashboard</a>
      </li>
      <li class="nav-item" style="margin:auto; width:100%;">
        <a class="nav-link" id="booking_footer" href="<?=base_url("/index.php/bookingowner");?>" style="padding:10px">Bookings</a>
      </li>
      <li class="nav-item" style="margin:auto; width:100%;">
        <a class="nav-link" id="report_footer" href="<?=base_url("/index.php/reportowner");?>" style="padding:10px">Report</a>
      </li>
      <li class="nav-item" style="margin:auto; width:100%;">
        <a class="nav-link" id="management_footer" href="<?=base_url("/index.php/managementowner");?>" style="padding:10px">Manage</a>
      </li>
    </ul>
</nav>
</footer>