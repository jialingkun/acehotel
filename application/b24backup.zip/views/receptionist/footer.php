<footer>
<nav class="navbar fixed-bottom navbar-expand navbar-light bg-light text-center no-padding" >
    <ul class="navbar-nav" style="margin:auto; width:100%;">
      <li class="nav-item " style="margin:auto; width:100%;">
        <a class="nav-link" id="dashboard_footer" href="<?=base_url("/index.php/dashboardreceptionist");?>" style="padding:10px">Dashboard</a>
      </li>
      <li class="nav-item" style="margin:auto; width:100%;">
        <a class="nav-link" id="booking_footer" href="<?=base_url("/index.php/bookingreceptionist");?>" style="padding:10px">Bookings</a>
      </li>
    </ul>
</nav>
</footer>