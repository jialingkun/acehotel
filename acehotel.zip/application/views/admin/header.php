<header>
<nav class="navbar fixed-top navbar-dark bg-primary">
  <a class="navbar-brand" id="header_title" style="color:white"></a>
</nav>
</header>