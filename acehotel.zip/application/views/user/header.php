<header>
<nav class="navbar fixed-top navbar-dark bg-primary">
  <!-- <a class="navbar-brand" id="header_title" style="color:white"></a> -->
  
  
  <header class="header">
        <!-- Logo -->
        <a href="#" class="logo" id="header_title"></a>
        <!-- Hamburger icon -->
        <input class="side-menu" type="checkbox" id="side-menu"/>
        <!-- <label class="hamb" for="side-menu"><span class="hamb-line"></span></label> -->
        <!-- Menu -->
        <nav class="nav">
            <ul class="menu">
                <li><a href="#">Dasboard</a></li>
                <li><a href="#">Explore Hotel</a> </li>
                <li><a href="#">Pesanan</a> </li>
                <li><a href="#">Akun</a></li>
            </ul>
        </nav>
    </header>
</nav>
</header>